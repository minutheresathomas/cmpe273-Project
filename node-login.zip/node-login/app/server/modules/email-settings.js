
module.exports = {

	host		: 'smtp.gmail.com',
	user 		: 'your-email-address@gmail.com',
	password 	: 'your-email-password',
	sender		: 'Your Name <your-email-address@gmail.com>'

}