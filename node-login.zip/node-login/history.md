####1.3.2 / 2013-03-11
	* fixed bug on password reset

####1.3.1 / 2013-03-07
	* adding MIT license

####1.3.0 / 2013-01-10
	* updating to express.js v3.0.6

####1.2.1 / 2013-01-03
	* moving vendor libs to /public/vendor

####1.2.0 / 2012-12-27
    * updating mongodb driver to 1.2.7
    * replacing bcrypt module with native crypto

####1.1.0 / 2012-08-12
    * adding /print & /reset methods

####1.0.0 / 2012-08-07
    * initial release

